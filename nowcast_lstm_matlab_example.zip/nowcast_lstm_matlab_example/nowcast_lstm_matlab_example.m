% note, an even more in-depth graphical walkthrough is available on the Python repo: https://github.com/dhopp1/nowcast_lstm

% LSTM library requirements
%pe = pyenv('Version', path_to_python); % may need to run the first time you use Python in MATLAB
addpath('your_path/nowcast_lstm_matlab/functions');

% initialize Python session
initialize_session();

% data read
my_df = readtable("data.csv");
my_df = my_df(:, ["date" "x_world" "x_nl" "x_de" "x_cn"]); % selecting subset of columns for ease
my_df = make_double(my_df); % converting columns to doubles, may not be necessary for your dataset

% defining parameters for the model
% this is a workaround because MATLAB doesn't have named parameters or default parameter values. You can set any parameters you want here, anything you don't specify will be given the default value
% only up to n_timesteps is required, anything else is optional
my_params = containers.Map;
my_params('data') = my_df;
my_params('target_variable') = 'x_world'; % our target variable
my_params('n_timesteps') = 12;
my_params('n_models') = 1;
my_params('train_episodes') = 50;
%my_params('fill_ragged_edges_func') = "ARMA"; % to use ARMA filling instead of mean filling, will take a bit longer to calculate

% now generate the final parameters for the model, taking defaults for anything that wasn't specified in my_params
params = gen_lstm_parameters(my_params);

% instantiate the LSTM model, passing the parameters just generated. The {:} notation is necessary at the end of params
% in MATLAB, the `model` variable holds the string variable name/key for the model in Python
model = LSTM(params{:});

% train the LSTM model.
train(model, true);

% generate predictions from this model on the train set. my_df is the MATLAB dataframe, can also be a new dataframe with the same columns as the data the model was trained on. true is whether to calculate predictions only for observations where an actual value exists.
preds = predict(model, my_df, true);

% save a trained model. File path must end in '.pkl'
save_lstm(model, "test.pkl");

% load a trained model, calling it 'new_model' as not to overwrite 'model',
% which in this session already exists. Model can now be used with
% LSTM.predict("new_model", ...)
new_model = load_lstm("test.pkl");

% generate predictions on an artificially ragged dataset. [1 2 3] is the
% (invented) publication lags of our 3 input variables ("x_nl", "x_de",
% "x_cn"), how many periods/months they take to be published. -3 is the
% simulated vintage, i.e. the data as it would have appeared 3 months
% before the target period. my_df is the data to predict on, "my_df" is the
% name in Python the same as the MATLAB name. "date" is the name of the
% date column in the data.
rag_preds = ragged_preds(model, [1 2 3], -3, my_df);

% the same as above but only performing for the selected date period
rag_preds2 = ragged_preds(model, [1 2 3], -3, my_df, "2019-01-01", "2020-01-01");

% generating contributions of new data to predictions
old_data = my_df; % copying data to make a synthetic "older" dataframe
old_data(end-5:end, 3) = {nan}; % setting two values to nan to simulate their not being published yet
old_data(end-6:end, 4) = {nan};

% generate news between the two datasets. "model" is which Python model to
% use. "2021-06-01" is the target period to compare (must exist in both
% datasets). old_data is the older dataset, my_df is the newer dataset.
% "date" is the name of the date column in both datasets.
news = gen_news(model, "2020-06-01", old_data, my_df);

% dataframe with contribution of new data to change in predictions
news('news');

% the prediction on the old data
news('old_pred');

% the prediction on the new data
news('new_pred');

% the scaling factor applied to make the contributions exactly the
% difference between the two predictions (should be near 1)
news('holdout_discrepency');

% helper function to convert columns to doubles, not specific to the library
function df = make_double(df)
    for k = 2:size(df, 2)
        col_name = df.Properties.VariableNames{k};
        if not(isnumeric(df.(col_name)))
            df.(col_name) = str2double(df.(col_name));
        end
    end
end


